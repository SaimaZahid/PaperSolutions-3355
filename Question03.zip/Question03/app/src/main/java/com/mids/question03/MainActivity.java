package com.mids.question03;


        import androidx.appcompat.app.AppCompatActivity;

        import android.graphics.Typeface;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnChangeColor, btnChangeTypeFace;
    private TextView txtHelloWorld;

    private int[] colors = {
            R.color.purple_200,
            R.color.purple_500,
            R.color.purple_700,
            R.color.teal_200,
            R.color.teal_700,
            R.color.black
    };
    private int selectedColor = 0;

    private Typeface[] typefaces = {
            Typeface.SANS_SERIF,
            Typeface.MONOSPACE,
            Typeface.DEFAULT
    };
    private int selectedTypeFace = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtHelloWorld = findViewById(R.id.txtHelloWorld);
        btnChangeColor = findViewById(R.id.btnChangeColor);
        btnChangeTypeFace = findViewById(R.id.btnChangeTypeFace);

        btnChangeColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeColor();
            }
        });

        btnChangeTypeFace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTypeFace();
            }
        });
    }

    private void changeColor() {
        if (selectedColor != 6) {
            txtHelloWorld.setTextColor(getColor(colors[selectedColor]));
            selectedColor++;
        } else {
            selectedColor = 0;
        }
    }

    private void changeTypeFace() {
        if (selectedTypeFace != 3) {
            txtHelloWorld.setTypeface(typefaces[selectedTypeFace]);
            selectedTypeFace++;
        } else {
            selectedTypeFace = 0;
        }
    }

}